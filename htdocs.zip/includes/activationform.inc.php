<!--<p style="margin-bottom: 24px;">Your profile is not yet active. Please, check the email address/phone number you provided when registering for the activation code to activate your account.</p>-->
  <form name="activate" id="activate" action="/" method="post">
      <div class="controls"><label>Activation Code:</label><input type="text" name="activationcode"></div>
      <div class="controls"><input type="submit" name="submit" id="submit" value="Activate"></div>
  </form>