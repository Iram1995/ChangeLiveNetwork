<?
///////////////////////////////////////////////////////////////////////////////
// How to setup PayPal in your website using PHP + MYSQL
// Author: Ideal Kamerolli
// Check out our website for more tutorials like this: https://dopehacker.com
///////////////////////////////////////////////////////////////////////////////
?>
<html>
<head>
<title>Payment has been cancelled</title>
</head>
<body>
<h1>Payment has been cancelled</h1>
</body>
</html>