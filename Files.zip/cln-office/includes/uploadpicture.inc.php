<form name="uploadpix" enctype="multipart/form-data" action="/admin/?section=changepix" method="post" class="registrationform">
    <div class="control-group">
        <div class="control double">
            <input type="file" name="picture">
            <!--<input type="hidden" name="task" value="Upload">-->
            <input type="submit" name="submit" value="Upload Picture">
        </div>
    </div>    
</form>