<?php

    include 'welcome/index.php';

?>