<?php

    $relationshiplist = array('' => 'Select Relationship','Son'=>'Son', 'Daughter'=>'Daughter','Brother'=>'Brother','Sister'=>'Sister','Husband'=>'Husband','Wife'=>'Wife','Others'=>'Others');
    $genderlist = array('' => 'Select Gender','Male'=>'Male', 'Female'=>'Female');
    $leglist = array('' => 'Select Leg','Left'=>'Left','Right'=>'Right');

?>
